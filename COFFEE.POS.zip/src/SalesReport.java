/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Ghel
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class SalesReport extends javax.swing.JFrame {

    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblTotalSales;

    public SalesReport() {
        initComponents();
        loadData();
    }

    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        lblTotalSales = new javax.swing.JLabel();
        lblTotalSales.setFont(new java.awt.Font("Segoe UI", 1, 16));
        lblTotalSales.setText("TOTAL SALES: ₱0.00");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Sales Report");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "ID", "Total", "Cash", "Change", "Payment Method", "Created At"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        .addComponent(lblTotalSales, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );  
        
        layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(lblTotalSales)
        .addGap(10, 10, 10)
           )
            );

        pack();
        setLocationRelativeTo(null);
    }

    private void loadData() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT * FROM sales";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            
            double grandTotal = 0;

            while (rs.next()) {
                 double total = rs.getDouble("total"); // get total per sale
                 grandTotal += total; // add to grand total
    
    
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getDouble("total"),
                    rs.getDouble("cash"),
                    rs.getDouble("change_amount"),
                    rs.getString("payment_method"),
                    rs.getString("created_at")
                });
            }
            
            lblTotalSales.setText("TOTAL SALES: ₱" + String.format("%.2f", grandTotal));
            
             
           

            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new SalesReport().setVisible(true);
        });
    }
}