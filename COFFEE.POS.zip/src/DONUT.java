/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author PC 001
 */
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.table.DefaultTableModel;

public class DONUT extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DONUT.class.getName());

    private final DefaultTableModel model;

    
    private final String productName;
    private final double basePrice;
    private double totalPrice;
    
    private void openKeypad() {
    NumberKeypad keypad = new NumberKeypad(txtQuantity);
    keypad.setVisible(true);
    }

    public DONUT(DefaultTableModel model, String name, double price) {
    initComponents();

    this.model = model;
    this.productName = name;
    this.basePrice = price;

    lblProductName.setText(name);
    txtQuantity.setText("1");
    txtQuantity.setEditable(true);  

    ((AbstractDocument) txtQuantity.getDocument()).setDocumentFilter(new DocumentFilter() {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string.matches("\\d*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    });

    txtQuantity.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }
    });

    calculatePrice();
    
    }
    
    private void calculatePrice() {

    int qty;
    try {
        qty = Integer.parseInt(txtQuantity.getText());
        if (qty <= 0) qty = 1; // prevent zero or negative
    } catch (NumberFormatException e) {
        qty = 1;
    }
    
    totalPrice = basePrice * qty;

    lblTotal.setText("Total: ₱" + String.format("%.2f", totalPrice));
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblProductName = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        btnMinus = new javax.swing.JButton();
        btnPlus = new javax.swing.JButton();
        btnAddToCart = new javax.swing.JButton();
        lblTotal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 204, 153));

        lblProductName.setBackground(new java.awt.Color(255, 255, 255));
        lblProductName.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblProductName.setForeground(new java.awt.Color(90, 45, 20));
        lblProductName.setText("jLabel1");

        txtQuantity.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtQuantity.setText("jTextField1");
        txtQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtQuantityMouseClicked(evt);
            }
        });
        txtQuantity.addActionListener(this::txtQuantityActionPerformed);

        btnMinus.setBackground(new java.awt.Color(239, 126, 0));
        btnMinus.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnMinus.setText("-");
        btnMinus.addActionListener(this::btnMinusActionPerformed);

        btnPlus.setBackground(new java.awt.Color(239, 126, 0));
        btnPlus.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPlus.setText("+");
        btnPlus.addActionListener(this::btnPlusActionPerformed);

        btnAddToCart.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAddToCart.setForeground(new java.awt.Color(90, 45, 20));
        btnAddToCart.setText("ADD TO CART");
        btnAddToCart.addActionListener(this::btnAddToCartActionPerformed);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotal.setText("Total: ₱0.00");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblTotal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addComponent(btnAddToCart))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(btnMinus)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnPlus)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMinus)
                    .addComponent(btnPlus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddToCart)
                    .addComponent(lblTotal))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPlusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlusActionPerformed
       int qty = Integer.parseInt(txtQuantity.getText());
    qty++;
    txtQuantity.setText(String.valueOf(qty));
    calculatePrice();
    }//GEN-LAST:event_btnPlusActionPerformed

    private void btnMinusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinusActionPerformed
      int qty = Integer.parseInt(txtQuantity.getText());

    if (qty > 1) {
        qty--;
        txtQuantity.setText(String.valueOf(qty));
        calculatePrice();
    }
    }//GEN-LAST:event_btnMinusActionPerformed

    private void txtQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtQuantityMouseClicked
     if (evt.getClickCount() == 2) {  
        openKeypad();               
    }
    }//GEN-LAST:event_txtQuantityMouseClicked

    private void btnAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToCartActionPerformed
          int qty;
    try {
        qty = Integer.parseInt(txtQuantity.getText());
    } catch (NumberFormatException e) {
        qty = 1; // fallback if invalid
    }

    // Check if the product already exists in the table
    boolean found = false;
    for (int i = 0; i < model.getRowCount(); i++) {
        if (model.getValueAt(i, 0).equals(productName)) { // Column 0 is Product
            // Update existing row: add qty, recalculate total
            int existingQty = (Integer) model.getValueAt(i, 1); // Column 1 is Qty
            int newQty = existingQty + qty;
            double newTotal = basePrice * newQty;
            model.setValueAt(newQty, i, 1); // Update Qty
            model.setValueAt(newTotal, i, 3); // Update Total (Column 3)
            found = true;
            break;
        }
    }

    if (!found) {
        // Add new row if product not found
        model.addRow(new Object[]{
            productName,
            qty,
            basePrice,
            totalPrice,
            "N/A"
        });
    }

    dispose(); // close donut dashboard
// close donut dashboard
    }//GEN-LAST:event_btnAddToCartActionPerformed

    private void txtQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQuantityActionPerformed
        //
    }//GEN-LAST:event_txtQuantityActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(() -> {
    DefaultTableModel tempModel = new DefaultTableModel(
        new Object[]{"Product", "Qty", "Price", "Total", "Payment"}, 0
    );
    new DONUT(tempModel, "Strewberry Rainbow", 65).setVisible(true);
});
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddToCart;
    private javax.swing.JButton btnMinus;
    private javax.swing.JButton btnPlus;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblProductName;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JTextField txtQuantity;
    // End of variables declaration//GEN-END:variables
}
