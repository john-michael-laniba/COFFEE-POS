/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author PC 001
 */

import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.CardLayout;
import javax.swing.table.DefaultTableModel;


public class CoffeeDashboard extends javax.swing.JFrame {
     private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CoffeeDashboard.class.getName());

    private final DefaultTableModel model;

   
    private final String productName;
    private final double basePrice;
    private double computedUnitPrice;
    private double computedTotalPrice;

    
     private CardLayout cardLayout;
     private String selectedSize;
     private String selectedSugar;
     private String selectedAddOn = "";
     
    
    
   
    public CoffeeDashboard(DefaultTableModel model, String name, double price) {
    initComponents();
    
    javax.swing.ButtonGroup bgSize = new javax.swing.ButtonGroup();
    bgSize.add(rbSmall);
    bgSize.add(rbMedium);
    bgSize.add(rbLarge);

    mainPanel.setLayout(new java.awt.CardLayout());
    cardLayout = (CardLayout) mainPanel.getLayout();
    
    mainPanel.add(jPanel1, "panelSize");
    mainPanel.add(panelSugar, "panelSugar");
    mainPanel.add(panelAddOn, "panelAddOn");
    mainPanel.add(panelConfirm, "panelConfirm");

    cardLayout.show(mainPanel, "panelSize");

    this.model = model;
    this.productName = name;
    this.basePrice = price;

    jLabel1.setText(name);
    txtQuantity.setText("1");
    txtQuantity.setEditable(true); 

    ((AbstractDocument) txtQuantity.getDocument()).setDocumentFilter(new DocumentFilter() {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string.matches("\\d*")) {  
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text.matches("\\d*")) { 
                super.replace(fb, offset, length, text, attrs);
            }
        }
    });

    txtQuantity.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }
        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }
        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            calculatePrice();
        }
    });

    rbSmall.setSelected(true);
    rbSmall.addActionListener(e -> {
        selectedSize = "Small";
        calculatePrice();
    });

    rbMedium.addActionListener(e -> {
        selectedSize = "Medium";
        calculatePrice();
    });

    rbLarge.addActionListener(e -> {
        selectedSize = "Large";
        calculatePrice();
    });

    jComboBox1.setSelectedIndex(2);

    calculatePrice();



    rbSmall.setSelected(true);
    rbSmall.addActionListener(e -> {
    selectedSize = "Small";
    calculatePrice();
});

rbMedium.addActionListener(e -> {
    selectedSize = "Medium";
    calculatePrice();
});

rbLarge.addActionListener(e -> {
    selectedSize = "Large";
    calculatePrice();
});
    jComboBox1.setSelectedIndex(2);
    
    

    calculatePrice();
}

    private CoffeeDashboard() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    final void calculatePrice() {

     int qty = 1;

    try {
        String text = txtQuantity.getText().trim();

        if (!text.isEmpty()) {
            qty = Integer.parseInt(text);
        }

        if (qty <= 0) {
            qty = 1;
        }

    } catch (NumberFormatException e) {
        qty = 1;
    }

    double price = basePrice;

    // SIZE
    if ("Medium".equals(selectedSize)) price += 20;
    if ("Large".equals(selectedSize)) price += 40;

    // ADD ONS
    if (selectedAddOn != null) {
        if (selectedAddOn.contains("ExtraShot")) price += 30;
        if (selectedAddOn.contains("WhippedCream")) price += 20;
        if (selectedAddOn.contains("Pearls")) price += 15;
    }

    computedUnitPrice = price;
    computedTotalPrice = price * qty;

    lblTotal.setText("Total: ₱" + String.format("%.2f", computedTotalPrice));
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        mainPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        rbSmall = new javax.swing.JRadioButton();
        rbMedium = new javax.swing.JRadioButton();
        rbLarge = new javax.swing.JRadioButton();
        btnNextSize = new javax.swing.JButton();
        panelSugar = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        btnNextSugar = new javax.swing.JButton();
        btnBackSugar = new javax.swing.JButton();
        panelConfirm = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        btnPlus = new javax.swing.JButton();
        btnMinus = new javax.swing.JButton();
        lblTotal = new javax.swing.JLabel();
        btnAddToCart = new javax.swing.JButton();
        btnBackConfirm = new javax.swing.JButton();
        panelAddOn = new javax.swing.JPanel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        btnNextAddOn = new javax.swing.JButton();
        btnBackAddOn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        jButton7.setText("jButton7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainPanel.setBackground(new java.awt.Color(255, 204, 153));
        mainPanel.setPreferredSize(new java.awt.Dimension(219, 192));

        jPanel1.setBackground(new java.awt.Color(255, 204, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Choose Size");

        rbSmall.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbSmall.setText("SMALL");
        rbSmall.setToolTipText("");
        rbSmall.addActionListener(this::rbSmallActionPerformed);

        rbMedium.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbMedium.setText("MEDIUM");

        rbLarge.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbLarge.setText("LARGE");
        rbLarge.addActionListener(this::rbLargeActionPerformed);

        btnNextSize.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnNextSize.setForeground(new java.awt.Color(90, 45, 20));
        btnNextSize.setText("NEXT");
        btnNextSize.addActionListener(this::btnNextSizeActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnNextSize))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbLarge, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbSmall)
                            .addComponent(rbMedium, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 120, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbSmall)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbMedium)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbLarge)
                .addGap(18, 18, 18)
                .addComponent(btnNextSize)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        panelSugar.setBackground(new java.awt.Color(255, 204, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Choose Sugar Level");

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0%,", "25%,", "50%,", "75%,", "100%" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        btnNextSugar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnNextSugar.setForeground(new java.awt.Color(90, 45, 20));
        btnNextSugar.setText("NEXT");
        btnNextSugar.addActionListener(this::btnNextSugarActionPerformed);

        btnBackSugar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBackSugar.setText("BACK");
        btnBackSugar.addActionListener(this::btnBackSugarActionPerformed);

        javax.swing.GroupLayout panelSugarLayout = new javax.swing.GroupLayout(panelSugar);
        panelSugar.setLayout(panelSugarLayout);
        panelSugarLayout.setHorizontalGroup(
            panelSugarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSugarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelSugarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSugarLayout.createSequentialGroup()
                        .addComponent(btnBackSugar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnNextSugar))
                    .addGroup(panelSugarLayout.createSequentialGroup()
                        .addGroup(panelSugarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelSugarLayout.setVerticalGroup(
            panelSugarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSugarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelSugarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNextSugar)
                    .addComponent(btnBackSugar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelConfirm.setBackground(new java.awt.Color(255, 204, 153));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Confirm Order");

        txtQuantity.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtQuantity.setText("jTextField1");
        txtQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        txtQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtQuantityMouseClicked(evt);
            }
        });
        txtQuantity.addActionListener(this::txtQuantityActionPerformed);

        btnPlus.setBackground(new java.awt.Color(239, 126, 0));
        btnPlus.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPlus.setText("+");
        btnPlus.addActionListener(this::btnPlusActionPerformed);

        btnMinus.setBackground(new java.awt.Color(239, 126, 0));
        btnMinus.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnMinus.setText("-");
        btnMinus.addActionListener(this::btnMinusActionPerformed);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotal.setText("TOTAL");

        btnAddToCart.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAddToCart.setForeground(new java.awt.Color(90, 45, 20));
        btnAddToCart.setText("ORDER");
        btnAddToCart.addActionListener(this::btnAddToCartActionPerformed);

        btnBackConfirm.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBackConfirm.setText("BACK");
        btnBackConfirm.addActionListener(this::btnBackConfirmActionPerformed);

        javax.swing.GroupLayout panelConfirmLayout = new javax.swing.GroupLayout(panelConfirm);
        panelConfirm.setLayout(panelConfirmLayout);
        panelConfirmLayout.setHorizontalGroup(
            panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelConfirmLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelConfirmLayout.createSequentialGroup()
                        .addComponent(btnBackConfirm)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAddToCart))
                    .addGroup(panelConfirmLayout.createSequentialGroup()
                        .addGroup(panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addGroup(panelConfirmLayout.createSequentialGroup()
                                .addComponent(btnMinus)
                                .addGroup(panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelConfirmLayout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(lblTotal))
                                    .addGroup(panelConfirmLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnPlus)))))
                        .addGap(0, 23, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelConfirmLayout.setVerticalGroup(
            panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelConfirmLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPlus)
                    .addComponent(btnMinus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotal)
                .addGap(12, 12, 12)
                .addGroup(panelConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddToCart)
                    .addComponent(btnBackConfirm))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        panelAddOn.setBackground(new java.awt.Color(255, 204, 153));

        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jCheckBox1.setText("Extra Shot");
        jCheckBox1.addActionListener(this::jCheckBox1ActionPerformed);

        jCheckBox2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jCheckBox2.setText("Whipped Cream");

        jCheckBox3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jCheckBox3.setText("Pearls");
        jCheckBox3.addActionListener(this::jCheckBox3ActionPerformed);

        btnNextAddOn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnNextAddOn.setForeground(new java.awt.Color(90, 45, 20));
        btnNextAddOn.setText("NEXT");
        btnNextAddOn.addActionListener(this::btnNextAddOnActionPerformed);

        btnBackAddOn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnBackAddOn.setText("BACK");
        btnBackAddOn.addActionListener(this::btnBackAddOnActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Choose Add-ons");

        javax.swing.GroupLayout panelAddOnLayout = new javax.swing.GroupLayout(panelAddOn);
        panelAddOn.setLayout(panelAddOnLayout);
        panelAddOnLayout.setHorizontalGroup(
            panelAddOnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAddOnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAddOnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelAddOnLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(btnBackAddOn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(btnNextAddOn))
                    .addGroup(panelAddOnLayout.createSequentialGroup()
                        .addGroup(panelAddOnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jCheckBox1)
                            .addComponent(jCheckBox2)
                            .addComponent(jCheckBox3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelAddOnLayout.setVerticalGroup(
            panelAddOnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAddOnLayout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelAddOnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNextAddOn)
                    .addComponent(btnBackAddOn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelSugar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelAddOn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelSugar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 11, Short.MAX_VALUE)))
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(panelConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelAddOn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 473, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbLargeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbLargeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbLargeActionPerformed
    
    private void btnNextSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextSizeActionPerformed
        if (rbSmall.isSelected()) selectedSize = "Small";
        if (rbMedium.isSelected()) selectedSize = "Medium";
        if (rbLarge.isSelected()) selectedSize = "Large";

    cardLayout.show(mainPanel, "panelSugar");
    }//GEN-LAST:event_btnNextSizeActionPerformed

    private void btnNextSugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextSugarActionPerformed
    selectedSugar = jComboBox1.getSelectedItem().toString();

    cardLayout.show(mainPanel, "panelAddOn");
    }//GEN-LAST:event_btnNextSugarActionPerformed

    private void btnNextAddOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextAddOnActionPerformed
        selectedAddOn = "";

    if (jCheckBox1.isSelected()) selectedAddOn += "ExtraShot ";
    if (jCheckBox2.isSelected()) selectedAddOn += "WhippedCream ";
    if (jCheckBox3.isSelected()) selectedAddOn += "Pearls ";
    
    calculatePrice();

    cardLayout.show(mainPanel, "panelConfirm");
    }//GEN-LAST:event_btnNextAddOnActionPerformed

    private void btnAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToCartActionPerformed
          int qty;

    try {
        qty = Integer.parseInt(txtQuantity.getText());
    } catch (NumberFormatException e) {
        qty = 1;
    }

    String description = productName + 
            " | " + selectedSize +
            " | Sugar:" + selectedSugar +
            " | " + selectedAddOn;

    boolean found = false;

    for (int i = 0; i < model.getRowCount(); i++) {

        String existingDesc = model.getValueAt(i, 0).toString();

        if (existingDesc.equals(description)) {

            int existingQty = Integer.parseInt(model.getValueAt(i, 1).toString());
            int newQty = existingQty + qty;

            double unitPrice = Double.parseDouble(model.getValueAt(i, 2).toString());
            double newTotal = newQty * unitPrice;

            model.setValueAt(newQty, i, 1);
            model.setValueAt(newTotal, i, 3);

            found = true;
            break;
        }
    }

    if (!found) {
        model.addRow(new Object[]{
            description,
            qty,
            computedUnitPrice,
            computedTotalPrice,
            selectedSize
        });
    }

    dispose();

    }//GEN-LAST:event_btnAddToCartActionPerformed
private void openKeypad() {
        NumberKeypad nk = new NumberKeypad(txtQuantity);
        nk.setLocationRelativeTo(this);
        nk.setVisible(true);
    }
    private void btnPlusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlusActionPerformed
        int qty = Integer.parseInt(txtQuantity.getText());
    qty++;
    txtQuantity.setText(String.valueOf(qty));
    calculatePrice();
    }//GEN-LAST:event_btnPlusActionPerformed

    private void btnMinusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinusActionPerformed
        int qty = Integer.parseInt(txtQuantity.getText());

    if (qty > 1) {
        qty--;
        txtQuantity.setText(String.valueOf(qty));
        calculatePrice();
    }
    }//GEN-LAST:event_btnMinusActionPerformed

    private void txtQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQuantityActionPerformed

    private void txtQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtQuantityMouseClicked
          if (evt.getClickCount() == 2) {   
        openKeypad();
    }
    }//GEN-LAST:event_txtQuantityMouseClicked

    private void btnBackSugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackSugarActionPerformed
        cardLayout.show(mainPanel, "panelSize");

    }//GEN-LAST:event_btnBackSugarActionPerformed

    private void btnBackAddOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackAddOnActionPerformed
         cardLayout.show(mainPanel, "panelSugar");
    }//GEN-LAST:event_btnBackAddOnActionPerformed

    private void btnBackConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackConfirmActionPerformed
        cardLayout.show(mainPanel, "panelAddOn");
    }//GEN-LAST:event_btnBackConfirmActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void rbSmallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbSmallActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbSmallActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CoffeeDashboard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddToCart;
    private javax.swing.JButton btnBackAddOn;
    private javax.swing.JButton btnBackConfirm;
    private javax.swing.JButton btnBackSugar;
    private javax.swing.JButton btnMinus;
    private javax.swing.JButton btnNextAddOn;
    private javax.swing.JButton btnNextSize;
    private javax.swing.JButton btnNextSugar;
    private javax.swing.JButton btnPlus;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton7;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel panelAddOn;
    private javax.swing.JPanel panelConfirm;
    private javax.swing.JPanel panelSugar;
    private javax.swing.JRadioButton rbLarge;
    private javax.swing.JRadioButton rbMedium;
    private javax.swing.JRadioButton rbSmall;
    private javax.swing.JTextField txtQuantity;
    // End of variables declaration//GEN-END:variables
}
