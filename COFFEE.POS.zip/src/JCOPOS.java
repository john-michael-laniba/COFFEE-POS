
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author CLienT
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class JCOPOS extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger =
    java.util.logging.Logger.getLogger(JCOPOS.class.getName());


    DefaultTableModel model;
    
    double total = 0;
    double cash = 0;
    double balance = 0;
    String paymentMethod = "N/A";
    
    double discount = 0; 
    int donutCount = 0;  
    boolean discountApplied = false;  // Flag to prevent discount stacking
    


    public JCOPOS() {
        initComponents();                 
        model = (DefaultTableModel) jTable1.getModel();
        
    model.addTableModelListener((javax.swing.event.TableModelEvent e) -> {
        updateTotal(); 
        });
    
}
    private void updateTotal() {
    total = 0;
    donutCount = 0;  
    for (int i = 0; i < model.getRowCount(); i++) {
        String item = (String) model.getValueAt(i, 0);
        int qty = (int) Integer.parseInt(model.getValueAt(i, 1).toString());
        total += (double) model.getValueAt(i, 3);

        if (!item.toLowerCase().contains("latte") && !item.toLowerCase().contains("americano") &&
            !item.toLowerCase().contains("espresso") && !item.toLowerCase().contains("cappuccino") &&
            !item.toLowerCase().contains("frappe") && !item.toLowerCase().contains("mocha") &&
            !item.toLowerCase().contains("free")) {  // Exclude free items
            donutCount += qty;
        }
    }

    total -= discount;
    applyPromos();

    lblTotalLabel.setText(String.format("₱%.2f", total));
}
private void applyPromos() {
    
    boolean hasFreeCoffee6 = false;
    boolean hasFreeCoffee12 = false;
    for (int i = 0; i < model.getRowCount(); i++) {
        String item = (String) model.getValueAt(i, 0);
        
        if (item.equals("Free Espresso") && donutCount >= 6) hasFreeCoffee6 = true;
        if (item.equals("Ice Americano") && donutCount >= 12) hasFreeCoffee12 = true;
    }
    if (donutCount >= 6 && !hasFreeCoffee6) {
        model.addRow(new Object[]{"Free Espresso", 1, 0.00, 0.00, "Regular"});
    }
    if (donutCount >= 12 && !hasFreeCoffee12) {
        model.addRow(new Object[]{"Ice Americano", 1, 0.00, 0.00, "Regular"});
    }
}

private String generateReceipt() {
    StringBuilder receipt = new StringBuilder();

    receipt.append("===== JCOPOS RECEIPT =====\n");
    receipt.append("Payment Method: ").append(paymentMethod).append("\n");
    receipt.append("--------------------------\n");

    for (int i = 0; i < model.getRowCount(); i++) {
        receipt.append(model.getValueAt(i, 0)).append(" ");
        receipt.append(model.getValueAt(i, 1)).append(" ");
        receipt.append("x").append(model.getValueAt(i, 2)).append(" - ");
        receipt.append(model.getValueAt(i, 3)).append("\n");
    }

    receipt.append("--------------------------\n");

    if (discount > 0) {
        receipt.append("DISCOUNT: ₱").append(String.format("%.2f", discount)).append("\n");
    }

    receipt.append("TOTAL: ₱").append(String.format("%.2f", total)).append("\n");
    receipt.append("CASH: ₱").append(String.format("%.2f", cash)).append("\n");
    receipt.append("CHANGE: ₱").append(String.format("%.2f", balance)).append("\n");
    receipt.append("==========================\n");

    return receipt.toString();
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        productPanel1 = new javax.swing.JPanel();
        btnOreology = new javax.swing.JButton();
        btnAvocadoDicap = new javax.swing.JButton();
        btnAlcapone = new javax.swing.JButton();
        btnCheese = new javax.swing.JButton();
        btnMatcha = new javax.swing.JButton();
        btnBlueberry = new javax.swing.JButton();
        btnChocolate = new javax.swing.JButton();
        btnGlazed = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnGlazed1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        productPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnEspresso = new javax.swing.JButton();
        btnHazelnut = new javax.swing.JButton();
        btnIcedAmericano = new javax.swing.JButton();
        btnCappuci = new javax.swing.JButton();
        btnIcedlatte = new javax.swing.JButton();
        btnCaramelFrappe = new javax.swing.JButton();
        btnOreoFrappe = new javax.swing.JButton();
        btnAmericano = new javax.swing.JButton();
        btnLatte = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnRemove = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        lblCash11 = new javax.swing.JLabel();
        lblChange11 = new javax.swing.JLabel();
        btnPay = new javax.swing.JButton();
        lblTotal11 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblTotalLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        lblCashLabel = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        lblChangeLabel = new javax.swing.JLabel();
        btnSalesReport = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(62, 39, 35));

        jPanel1.setBackground(new java.awt.Color(93, 64, 55));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(51, 0, 0));
        jLabel1.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Café de Grand Père");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(525, 525, 525))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(16, 16, 16))
        );

        jPanel3.setBackground(new java.awt.Color(255, 51, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        productPanel1.setBackground(new java.awt.Color(239, 224, 208));

        btnOreology.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnOreology.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/oreology.png"))); // NOI18N
        btnOreology.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOreologyActionPerformed(evt);
            }
        });

        btnAvocadoDicap.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAvocadoDicap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/avocadoD.png"))); // NOI18N
        btnAvocadoDicap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvocadoDicapActionPerformed(evt);
            }
        });

        btnAlcapone.setBackground(new java.awt.Color(255, 248, 240));
        btnAlcapone.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAlcapone.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/alcaponeeeee.png"))); // NOI18N
        btnAlcapone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlcaponeActionPerformed(evt);
            }
        });

        btnCheese.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCheese.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/cheese.png"))); // NOI18N
        btnCheese.setMaximumSize(new java.awt.Dimension(156, 157));
        btnCheese.setMinimumSize(new java.awt.Dimension(156, 157));
        btnCheese.setPreferredSize(new java.awt.Dimension(156, 157));
        btnCheese.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheeseActionPerformed(evt);
            }
        });

        btnMatcha.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnMatcha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/matchaa.png"))); // NOI18N
        btnMatcha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMatchaActionPerformed(evt);
            }
        });

        btnBlueberry.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBlueberry.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/bluesss.png"))); // NOI18N
        btnBlueberry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBlueberryActionPerformed(evt);
            }
        });

        btnChocolate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnChocolate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/chocooo.png"))); // NOI18N
        btnChocolate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChocolateActionPerformed(evt);
            }
        });

        btnGlazed.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnGlazed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/glazee.png"))); // NOI18N
        btnGlazed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGlazedActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(51, 0, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("DONUTS");

        btnGlazed1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnGlazed1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/strewwww.png"))); // NOI18N
        btnGlazed1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGlazed1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(90, 45, 20));
        jLabel5.setText("Oreology");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(90, 45, 20));
        jLabel6.setText("Avocado Dicaprio");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(90, 45, 20));
        jLabel7.setText("Alcapone");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(90, 45, 20));
        jLabel8.setText("Cheesecakelicious");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(90, 45, 20));
        jLabel9.setText("Matchalicious");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(90, 45, 20));
        jLabel10.setText("Blueberrymore");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(90, 45, 20));
        jLabel11.setText("Chocolate Sprinkles");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(90, 45, 20));
        jLabel12.setText("Glazed");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(90, 45, 20));
        jLabel13.setText("Strawberry Rainbow");

        javax.swing.GroupLayout productPanel1Layout = new javax.swing.GroupLayout(productPanel1);
        productPanel1.setLayout(productPanel1Layout);
        productPanel1Layout.setHorizontalGroup(
            productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel1Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(67, 67, 67)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel1Layout.createSequentialGroup()
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(productPanel1Layout.createSequentialGroup()
                        .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel1Layout.createSequentialGroup()
                                .addGap(0, 11, Short.MAX_VALUE)
                                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnCheese, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnChocolate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(productPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel11))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(btnOreology, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(productPanel1Layout.createSequentialGroup()
                                .addComponent(btnAvocadoDicap, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(btnAlcapone, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(productPanel1Layout.createSequentialGroup()
                                .addComponent(btnMatcha, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(btnBlueberry, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(productPanel1Layout.createSequentialGroup()
                                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnGlazed, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(productPanel1Layout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(26, 26, 26)
                                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(productPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel13))
                                    .addComponent(btnGlazed1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(productPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addGap(22, 22, 22))
        );
        productPanel1Layout.setVerticalGroup(
            productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(productPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnAvocadoDicap, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnOreology, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnAlcapone, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(productPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(11, 11, 11))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                    .addGroup(productPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnMatcha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCheese, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBlueberry, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGlazed1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChocolate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGlazed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addGroup(productPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jLabel12)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        productPanel2.setBackground(new java.awt.Color(239, 224, 208));
        productPanel2.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("COFFEE/FRAPPE");

        btnEspresso.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEspresso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/aaaa.png"))); // NOI18N
        btnEspresso.setMaximumSize(new java.awt.Dimension(156, 157));
        btnEspresso.setMinimumSize(new java.awt.Dimension(156, 157));
        btnEspresso.setPreferredSize(new java.awt.Dimension(156, 157));
        btnEspresso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEspressoActionPerformed(evt);
            }
        });

        btnHazelnut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnHazelnut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hazel222.png"))); // NOI18N
        btnHazelnut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHazelnutActionPerformed(evt);
            }
        });

        btnIcedAmericano.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnIcedAmericano.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kkkkk.png"))); // NOI18N
        btnIcedAmericano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIcedAmericanoActionPerformed(evt);
            }
        });

        btnCappuci.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCappuci.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/capppppp.png"))); // NOI18N
        btnCappuci.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCappuciActionPerformed(evt);
            }
        });

        btnIcedlatte.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnIcedlatte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hazel.png"))); // NOI18N
        btnIcedlatte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIcedlatteActionPerformed(evt);
            }
        });

        btnCaramelFrappe.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCaramelFrappe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/123123.png"))); // NOI18N
        btnCaramelFrappe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaramelFrappeActionPerformed(evt);
            }
        });

        btnOreoFrappe.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnOreoFrappe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/oreoooooo.png"))); // NOI18N
        btnOreoFrappe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOreoFrappeActionPerformed(evt);
            }
        });

        btnAmericano.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAmericano.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/ameriiii.png"))); // NOI18N
        btnAmericano.setMaximumSize(new java.awt.Dimension(156, 157));
        btnAmericano.setMinimumSize(new java.awt.Dimension(156, 157));
        btnAmericano.setPreferredSize(new java.awt.Dimension(156, 157));
        btnAmericano.setRequestFocusEnabled(false);
        btnAmericano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAmericanoActionPerformed(evt);
            }
        });

        btnLatte.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnLatte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PICTURE/123.png"))); // NOI18N
        btnLatte.setMaximumSize(new java.awt.Dimension(156, 157));
        btnLatte.setMinimumSize(new java.awt.Dimension(156, 157));
        btnLatte.setPreferredSize(new java.awt.Dimension(156, 157));
        btnLatte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLatteActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(90, 45, 20));
        jLabel17.setText("Americano");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(90, 45, 20));
        jLabel18.setText("Espresso");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(90, 45, 20));
        jLabel19.setText("Cappuccino");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(90, 45, 20));
        jLabel20.setText("Hazelnut Latte");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(90, 45, 20));
        jLabel21.setText("Mocha Espresso");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(90, 45, 20));
        jLabel22.setText("Latte");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(90, 45, 20));
        jLabel23.setText("Oreo Frappe");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(90, 45, 20));
        jLabel24.setText("Caramel Frappe");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(90, 45, 20));
        jLabel25.setText("Ice Americano");

        javax.swing.GroupLayout productPanel2Layout = new javax.swing.GroupLayout(productPanel2);
        productPanel2.setLayout(productPanel2Layout);
        productPanel2Layout.setHorizontalGroup(
            productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(productPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, productPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(productPanel2Layout.createSequentialGroup()
                        .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(productPanel2Layout.createSequentialGroup()
                                    .addComponent(btnHazelnut, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnIcedlatte, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCappuci, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(productPanel2Layout.createSequentialGroup()
                                    .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, productPanel2Layout.createSequentialGroup()
                                            .addGap(29, 29, 29)
                                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(73, 73, 73)
                                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(productPanel2Layout.createSequentialGroup()
                                            .addComponent(btnAmericano, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(btnEspresso, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(18, 18, 18)
                                    .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(btnLatte, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(productPanel2Layout.createSequentialGroup()
                                    .addGap(22, 22, 22)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(61, 61, 61)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)))
                            .addGroup(productPanel2Layout.createSequentialGroup()
                                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(productPanel2Layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel2Layout.createSequentialGroup()
                                        .addGap(0, 20, Short.MAX_VALUE)
                                        .addComponent(btnOreoFrappe, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)))
                                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel2Layout.createSequentialGroup()
                                        .addComponent(btnCaramelFrappe, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnIcedAmericano, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(68, 68, 68)
                                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(21, 21, 21)))))
                        .addGap(24, 24, 24))))
        );
        productPanel2Layout.setVerticalGroup(
            productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(productPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(productPanel2Layout.createSequentialGroup()
                        .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnEspresso, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAmericano, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLatte, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(productPanel2Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(productPanel2Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel18))))
                    .addComponent(jLabel22))
                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(productPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnCappuci, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnIcedlatte, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(productPanel2Layout.createSequentialGroup()
                        .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(productPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(btnHazelnut, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel20))
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnIcedAmericano, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnCaramelFrappe, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnOreoFrappe, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(productPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel24)
                        .addComponent(jLabel25))
                    .addComponent(jLabel23))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(239, 224, 208));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Qty", "Price", "Total", "Size"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel3.setBackground(new java.awt.Color(51, 0, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("ORDER");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        btnRemove.setBackground(new java.awt.Color(191, 142, 104));
        btnRemove.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnRemove.setForeground(new java.awt.Color(50, 50, 50));
        btnRemove.setText("REMOVE");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(191, 142, 104));
        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnClear.setForeground(new java.awt.Color(50, 50, 50));
        btnClear.setText("CANCEL ORDER");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        lblCash11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblCash11.setForeground(new java.awt.Color(255, 255, 255));
        lblCash11.setText("CASH:");
        lblCash11.setPreferredSize(new java.awt.Dimension(80, 25));

        lblChange11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblChange11.setForeground(new java.awt.Color(255, 255, 255));
        lblChange11.setText("CHANGE:");

        btnPay.setBackground(new java.awt.Color(191, 142, 104));
        btnPay.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPay.setForeground(new java.awt.Color(50, 50, 50));
        btnPay.setText("PAY");
        btnPay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPayActionPerformed(evt);
            }
        });

        lblTotal11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotal11.setForeground(new java.awt.Color(255, 255, 255));
        lblTotal11.setText("TOTAL:");
        lblTotal11.setPreferredSize(new java.awt.Dimension(80, 25));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblTotalLabel.setBackground(new java.awt.Color(255, 255, 255));
        lblTotalLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotalLabel.setText(" ₱0.00");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(lblTotalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblTotalLabel))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblCashLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblCashLabel.setText(" ₱0.00");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(lblCashLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 25, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblCashLabel))
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblChangeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblChangeLabel.setText(" ₱0.00");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(lblChangeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 16, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblChangeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        btnSalesReport.setBackground(new java.awt.Color(191, 142, 104));
        btnSalesReport.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSalesReport.setForeground(new java.awt.Color(50, 50, 50));
        btnSalesReport.setText("SALES REPORT");
        btnSalesReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalesReportActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(productPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(lblTotal11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblCash11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblChange11)
                                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(productPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(btnSalesReport, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnPay, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(productPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(productPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTotal11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblCash11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblChange11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPay, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalesReport, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLatteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLatteActionPerformed
       CoffeeDashboard cd = new CoffeeDashboard(model, "Latte", 120);
       cd.setLocationRelativeTo(this);
       cd.setVisible(true);
    }//GEN-LAST:event_btnLatteActionPerformed

    private void btnAmericanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAmericanoActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Americano", 100);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnAmericanoActionPerformed

    private void btnOreoFrappeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOreoFrappeActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Oreo Frappe", 150);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnOreoFrappeActionPerformed

    private void btnCaramelFrappeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaramelFrappeActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Caramel Frappe", 150);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnCaramelFrappeActionPerformed

    private void btnIcedlatteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIcedlatteActionPerformed
       CoffeeDashboard cd = new CoffeeDashboard(model, "Mocha Espresso", 150);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnIcedlatteActionPerformed

    private void btnCappuciActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCappuciActionPerformed
       CoffeeDashboard cd = new CoffeeDashboard(model, "Capuccino", 120);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnCappuciActionPerformed

    private void btnIcedAmericanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIcedAmericanoActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Iced Americano", 110);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnIcedAmericanoActionPerformed

    private void btnHazelnutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHazelnutActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Hazel Latte", 130);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnHazelnutActionPerformed

    private void btnEspressoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEspressoActionPerformed
        CoffeeDashboard cd = new CoffeeDashboard(model, "Espresso", 90);
        cd.setLocationRelativeTo(this);
        cd.setVisible(true);
    }//GEN-LAST:event_btnEspressoActionPerformed

    private void btnGlazed1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGlazed1ActionPerformed
        DONUT dd;  
        dd = new DONUT(model, "Strawberry Rainbow", 65.0);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnGlazed1ActionPerformed

    private void btnGlazedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGlazedActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Glazed", 35.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnGlazedActionPerformed

    private void btnChocolateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChocolateActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Chocolate Sprinkle", 65.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnChocolateActionPerformed

    private void btnBlueberryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBlueberryActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Blueberrymore", 70.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnBlueberryActionPerformed

    private void btnMatchaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMatchaActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Matchalicious", 75.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnMatchaActionPerformed

    private void btnCheeseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheeseActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Cheesecakelicious", 75.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnCheeseActionPerformed

    private void btnAlcaponeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlcaponeActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Alcapone", 75.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnAlcaponeActionPerformed

    private void btnAvocadoDicapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvocadoDicapActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Avocado Dacaprio", 75.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnAvocadoDicapActionPerformed

    private void btnOreologyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOreologyActionPerformed
        DONUT dd;
        dd = new DONUT(model, "Oreology", 75.00);
        dd.setLocationRelativeTo(this);
        dd.setVisible(true);
    }//GEN-LAST:event_btnOreologyActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Please select an item to remove");
            return;
        }

        model.removeRow(selectedRow);
        updateTotal();
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
                                        
    if (model.getRowCount() == 0) {
        javax.swing.JOptionPane.showMessageDialog(
            this,
            "No order to cancel."
        );
        return;
    }

    int choice = javax.swing.JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to cancel the order?",
        "Cancel Order Confirmation",
        javax.swing.JOptionPane.YES_NO_OPTION
    );

    if (choice == JOptionPane.YES_OPTION) {
        model.setRowCount(0);
        total = 0;
        cash = 0;
        balance = 0;
        discount = 0;  // Reset discount
        donutCount = 0;  // Reset donut count
        discountApplied = false;  // Reset discount flag
        paymentMethod = "N/A";
        lblTotalLabel.setText("₱0.00");
        lblCashLabel.setText("₱0.00");
        lblChangeLabel.setText("₱0.00");
    }


    }//GEN-LAST:event_btnClearActionPerformed

    private void btnPayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPayActionPerformed
        double originalTotal = total;

    int confirm = JOptionPane.showConfirmDialog(this, "Confirm order?", "Confirm", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) {
        return;  
    }

    String[] paymentOptions = {"Cash", "GCash", "Maya"};
    String selectedMethod = (String) JOptionPane.showInputDialog(this,
            "Select Payment Method:",
            "Payment Method",
            JOptionPane.PLAIN_MESSAGE,
            null,
            paymentOptions,
            paymentOptions[0]);

    if (selectedMethod == null) {
        return;  
    }

    paymentMethod = selectedMethod;

    String[] discountOptions = {"None", "PWD (10% off)", "Senior Citizen (10% off)"};
    String selectedDiscount = (String) JOptionPane.showInputDialog(this,
            "Select Discount (if applicable):",
            "Discount",
            JOptionPane.PLAIN_MESSAGE,
            null,
            discountOptions,
            discountOptions[0]);

    if (selectedDiscount == null) {
        return;  
    }

    // APPLY DISCOUNT
    if (!selectedDiscount.equals("None") && !discountApplied) {
        discount = originalTotal * 0.10;
        total = originalTotal - discount;
        lblTotalLabel.setText(String.format("₱%.2f", total));  
        discountApplied = true;  
    }

    // CASH HANDLING
    if (paymentMethod.equals("Cash")) {
        String cashStr = JOptionPane.showInputDialog(this, "Enter Cash Amount:", "Cash Payment", JOptionPane.PLAIN_MESSAGE);
        if (cashStr == null) {
            total = originalTotal;
            lblTotalLabel.setText(String.format("₱%.2f", total));
            discountApplied = false;
            return;
        }

        try {
            cash = Double.parseDouble(cashStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid cash amount.", "Error", JOptionPane.ERROR_MESSAGE);
            total = originalTotal;
            lblTotalLabel.setText(String.format("₱%.2f", total));
            discountApplied = false;
            return;
        }

        if (cash < total) {
            JOptionPane.showMessageDialog(this, "Cash must be at least total amount.", "Error", JOptionPane.ERROR_MESSAGE);
            total = originalTotal;
            lblTotalLabel.setText(String.format("₱%.2f", total));
            discountApplied = false;
            return;
        }

        balance = cash - total;

    } else {
        cash = 0.0;
        balance = 0.0;
    }

    // CHECK EMPTY CART
    if (model.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No items in cart. Please add items first.");
        total = originalTotal;
        lblTotalLabel.setText(String.format("₱%.2f", total));
        discountApplied = false;
        return;
    }

    // ✅ PAYMENT SUCCESS — UPDATE UI
    lblTotalLabel.setText(String.format("₱%.2f", total));
    lblCashLabel.setText(String.format("₱%.2f", cash));
    lblChangeLabel.setText(String.format("₱%.2f", balance));

    // ✅ SAVE TO DATABASE (CORRECT PLACE)
    try {
        Connection con = DBConnection.getConnection();  

        // 1️⃣ SAVE SALE
        String saleSQL = "INSERT INTO sales (total, cash, change_amount, payment_method) VALUES (?, ?, ?, ?)";
        PreparedStatement pstSale = con.prepareStatement(saleSQL, Statement.RETURN_GENERATED_KEYS);

        pstSale.setDouble(1, total);
        pstSale.setDouble(2, cash);
        pstSale.setDouble(3, balance);
        pstSale.setString(4, paymentMethod);

        pstSale.executeUpdate();

        // GET sale_id
        ResultSet rs = pstSale.getGeneratedKeys();
        int saleId = 0;

        if (rs.next()) {
            saleId = rs.getInt(1);
        }

        // 2️⃣ SAVE ITEMS
        String itemSQL = "INSERT INTO sale_items (sale_id, item_name, qty, price, total) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pstItem = con.prepareStatement(itemSQL);

        for (int i = 0; i < model.getRowCount(); i++) {

            pstItem.setInt(1, saleId);
            pstItem.setString(2, model.getValueAt(i, 0).toString());
            pstItem.setInt(3, Integer.parseInt(model.getValueAt(i, 1).toString()));
            pstItem.setDouble(4, Double.parseDouble(model.getValueAt(i, 2).toString()));
            pstItem.setDouble(5, Double.parseDouble(model.getValueAt(i, 3).toString()));

            pstItem.executeUpdate();
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error saving to database!");
    }

    // RECEIPT
    String receipt = generateReceipt();
    JOptionPane.showMessageDialog(this, "Order sent to kitchen!");

    ReceiptFrame rf = new ReceiptFrame();
    rf.setReceiptText(receipt);
    rf.setLocationRelativeTo(this);
    rf.setVisible(true);

    // RESET AFTER CLOSE
    rf.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosed(java.awt.event.WindowEvent e) {

            JOptionPane.showMessageDialog(null, "Order completed!");
            lblTotalLabel.setText("₱0.00");
            lblCashLabel.setText("₱0.00");
            lblChangeLabel.setText("₱0.00");

            total = 0;
            cash = 0;
            balance = 0;
            discount = 0;
            donutCount = 0;
            discountApplied = false;

            model.setRowCount(0);
        }
    });                       
    }//GEN-LAST:event_btnPayActionPerformed

    private void btnSalesReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalesReportActionPerformed
      SalesReport sr = new SalesReport();
    sr.setLocationRelativeTo(this);
    sr.setVisible(true);
    }//GEN-LAST:event_btnSalesReportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(() -> new Login_Application().setVisible(true));
    }
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlcapone;
    private javax.swing.JButton btnAmericano;
    private javax.swing.JButton btnAvocadoDicap;
    private javax.swing.JButton btnBlueberry;
    private javax.swing.JButton btnCappuci;
    private javax.swing.JButton btnCaramelFrappe;
    private javax.swing.JButton btnCheese;
    private javax.swing.JButton btnChocolate;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnEspresso;
    private javax.swing.JButton btnGlazed;
    private javax.swing.JButton btnGlazed1;
    private javax.swing.JButton btnHazelnut;
    private javax.swing.JButton btnIcedAmericano;
    private javax.swing.JButton btnIcedlatte;
    private javax.swing.JButton btnLatte;
    private javax.swing.JButton btnMatcha;
    private javax.swing.JButton btnOreoFrappe;
    private javax.swing.JButton btnOreology;
    private javax.swing.JButton btnPay;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSalesReport;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblCash11;
    private javax.swing.JLabel lblCashLabel;
    private javax.swing.JLabel lblChange11;
    private javax.swing.JLabel lblChangeLabel;
    private javax.swing.JLabel lblTotal11;
    private javax.swing.JLabel lblTotalLabel;
    private javax.swing.JPanel productPanel1;
    private javax.swing.JPanel productPanel2;
    // End of variables declaration//GEN-END:variables
}
